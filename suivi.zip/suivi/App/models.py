from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import User 
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import datetime;
from ckeditor.fields import RichTextField


# 1
class Personnel(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE,related_name="personnel_user")
    nom_prenom=models.CharField(max_length=100,blank=True, null=True)
    
    date_naissance =models.DateField(default=datetime.now,null=True)
    genre =models.CharField(max_length=100,null=True)
    role = models.CharField(max_length=50, null=True,choices=[('Choisisez','Choisisez'),('Administrateur', 'Administrateur'),('Responsable_de_projet', 'Responsable_de_projet'), ('Chef_d_equipe', 'Chef_d_equipe'), ('Technicien', 'Technicien')])
    telephone =models.CharField(max_length=100,null=True)
    address=models.CharField(max_length=100, null = True)
    date_enre=models.DateField(default=datetime.now,null=True)


    def __str__(self):
        return self.nom_prenom if self.nom_prenom else "Nom non spécifié"


#2
class Bailleur(models.Model):
    nom_societe=models.CharField(max_length=100,null=True)
    date_debut=models.DateField(null=True)
    date_fin=models.DateField()

    def __str__(self):
        return self.nom_societe if self.nom_societe else "Nom non spécifié"
#3
class Projet(models.Model):
    nom_projet=models.CharField(max_length=100,null=True)
    responsable_projet=models.ForeignKey(Personnel,on_delete=models.CASCADE,null=True)
    finance_par=models.ForeignKey(Bailleur,on_delete=models.CASCADE,null=True)
    date_debut=models.DateField(null=True)
    date_fin=models.DateField()
    description_projet=models.CharField(max_length=100,null=True)
    STATUS_CHOICES = [
        ('en_cours', 'En cours'),
        ('termine', 'Terminé'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='en_cours')

    def __str__(self):
        return self.nom_projet if self.nom_projet else "Nom non spécifié"
# 4

class UserActivity(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)  # Le champ timestamp pour enregistrer l'heure de l'action

    def __str__(self):
        return f"{self.user} - {self.action} at {self.timestamp}"


class Site(models.Model):
    nom_site = models.CharField(max_length=100, null=True)
    chef_d_equipe = models.ForeignKey(Personnel, on_delete=models.CASCADE, null=True)
    projet = models.ForeignKey(Projet, on_delete=models.CASCADE, null=True, related_name="sites")
    
    finance_par = models.ForeignKey(Bailleur, on_delete=models.CASCADE, null=True)
    lieu = models.CharField(max_length=100, null=True)
    personnel = models.ManyToManyField(Personnel, related_name='sites')
    date_debut = models.DateField(null=True)
    date_fin = models.DateField()

    def __str__(self):
        return self.nom_site if self.nom_site else "Nom non spécifié"

    def __str__(self):
        return f"{self.nom_site} - Projet: {self.projet.nom_projet if self.projet else 'Pas de projet associé'}"

    def clean(self):
        # Vérifier si ce chef d'équipe a déjà un site avec une date de fin future
        if self.chef_d_equipe:
            sites_actifs = Site.objects.filter(
                chef_d_equipe=self.chef_d_equipe,
                date_fin__gt=timezone.now()
            ).exclude(pk=self.pk)  # Exclure le site actuel si on le met à jour

            if sites_actifs.exists():
                raise ValidationError(
                    f"{self.chef_d_equipe.nom_prenom} est déjà en charge d'une équipe pour un site dont les activités ne sont pas encore terminées."
                )

        # Vérifier si ce personnel a déjà un site avec une date de fin future
        
#5
class Rapport(models.Model):
    personnel=models.ForeignKey(Personnel,on_delete=models.CASCADE,null=True)
    site=models.ForeignKey(Site,on_delete=models.CASCADE,null=True)
    titre_rapport=models.CharField(max_length=150,null=True)
    description = RichTextField(null=True) # Utilisation de CKEDITOR pour le champ de contenu
    date=models.DateField()
    STATUT_CHOICES = [
        ('Brouillon', 'Brouillon'),
        ('En attente', 'En attente de validation'),
        ('Valide', 'Validé'),
        ('Refuse', 'Refusé'),
    ]
    statut = models.CharField(max_length=10, choices=STATUT_CHOICES, default='Brouillon')

    def __str__(self):
        return self.titre_rapport if self.titre_rapport else "Nom non spécifié"
# 6
class Typemateriel(models.Model):
    nom_type_materel=models.CharField(max_length=100,null=True)
    
    def __str__(self):
        return self.nom_type_materel if self.nom_type_materel else "Nom non spécifié"
# 7
class Materiel(models.Model):
    site=models.ForeignKey(Site,on_delete=models.CASCADE,null=True) 
    nom_materiel=models.CharField(max_length=100,null=True)
    type_materiel=models.ForeignKey(Typemateriel,on_delete=models.CASCADE,null=True) 
    quantite_materiel=models.CharField(max_length=100,null=True)
    qualite=models.CharField(max_length=100,null=True)
    date_d_enregistrement=models.DateField(null=True) 
       
    def __str__(self) :
        return self.nom_materiel if self.nom_materiel else "Nom non spécifié"   



# 8
class Perdieme(models.Model) :
    personne_receveur=models.ForeignKey(Personnel,on_delete=models.CASCADE,null=True)
    site=models.ForeignKey(Site,on_delete=models.CASCADE,null=True)
    description= models.CharField(max_length=100,null=True)
    montant=models.IntegerField()
    date_transaction=models.DateField()
    code_transaction_numero_bordereau=models.CharField(max_length=100,null=True)
 
    def __str__(self):
        return self.description if self.description else "Nom non spécifié"

# 9
class PerdiemeValidation(models.Model):
    perdieme = models.ForeignKey(Perdieme, on_delete=models.CASCADE)
    personnel = models.ForeignKey(Personnel, on_delete=models.CASCADE)
    date_validation = models.DateField(auto_now_add=True)
    is_validated = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.personnel} - {self.perdieme}"
    
    
    
    
    
    

    
    